# java-programming-basic
 Tugas Kelompok dikumpulkan paling lambat seminggu sebelum UAS
Yg dinilai: Kerapihan UI, validasi input, Hasil Kalkulasi, Commentar tiap baris kode.

### 3C

#### 1.

#### 2.laju inflasi (nilai uang/barang pada tahun sekian ataupun tahun yg lalu).
  * input: tahun perhitungan, nilai inflasi dalam persen
  * output: nilai uang/barang

  1. a
  2. b
  3. c
  4. d
  5. e

#### 3.hitung pajak kendaraan tahunan
  * input: pajak pokok, asuransi fixed, bulan ke berapa, tarif denda per bulan fixed
  * output: total denda, total bayar

  1. a
  2. b
  3. c
  4. d
  5. e

#### 4.perhitungan jumlah bayar suatu barang dikasir
  * input: harga jual pokok, nilai diskon, diskon qty, jumlah barang yg dibeli
  * output: total diskon, total bayar

  1. a
  2. b
  3. c
  4. d
  5. e

#### 5.hitung gaji(nilai gaji yg diterima dari seorang bergaji X).
  * input: gaji pokok, total jam lembur, tidak masuk berapa kali, potongan per tidak masuk, tarif lembur.
  * output: total potongan, total lembur, total terima

  1. a
  2. b
  3. c
  4. d
  5. e

### 3D:

#### 1.a

#### 2.b 

#### 3.c

#### 4.d
